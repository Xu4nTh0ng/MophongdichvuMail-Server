﻿namespace connect
{
    partial class DangNhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_dangnhap = new System.Windows.Forms.Button();
            this.textbox_TenTK = new System.Windows.Forms.TextBox();
            this.textbox_pass = new System.Windows.Forms.TextBox();
            this.linkLabel_QuenPass = new System.Windows.Forms.LinkLabel();
            this.linkLabel_DangKy = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_dangnhap
            // 
            this.button_dangnhap.Location = new System.Drawing.Point(132, 377);
            this.button_dangnhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_dangnhap.Name = "button_dangnhap";
            this.button_dangnhap.Size = new System.Drawing.Size(155, 40);
            this.button_dangnhap.TabIndex = 3;
            this.button_dangnhap.Text = "Đăng nhập";
            this.button_dangnhap.UseVisualStyleBackColor = true;
            this.button_dangnhap.Click += new System.EventHandler(this.button_dangnhap_Click);
            // 
            // textbox_TenTK
            // 
            this.textbox_TenTK.Location = new System.Drawing.Point(118, 228);
            this.textbox_TenTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_TenTK.Name = "textbox_TenTK";
            this.textbox_TenTK.Size = new System.Drawing.Size(251, 23);
            this.textbox_TenTK.TabIndex = 0;
            // 
            // textbox_pass
            // 
            this.textbox_pass.Location = new System.Drawing.Point(118, 275);
            this.textbox_pass.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textbox_pass.Name = "textbox_pass";
            this.textbox_pass.PasswordChar = '♥';
            this.textbox_pass.Size = new System.Drawing.Size(251, 23);
            this.textbox_pass.TabIndex = 1;
            // 
            // linkLabel_QuenPass
            // 
            this.linkLabel_QuenPass.AutoSize = true;
            this.linkLabel_QuenPass.Location = new System.Drawing.Point(80, 330);
            this.linkLabel_QuenPass.Name = "linkLabel_QuenPass";
            this.linkLabel_QuenPass.Size = new System.Drawing.Size(89, 15);
            this.linkLabel_QuenPass.TabIndex = 3;
            this.linkLabel_QuenPass.TabStop = true;
            this.linkLabel_QuenPass.Text = "Quên mật khẩu";
            this.linkLabel_QuenPass.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_QuenPass_LinkClicked);
            // 
            // linkLabel_DangKy
            // 
            this.linkLabel_DangKy.AutoSize = true;
            this.linkLabel_DangKy.Location = new System.Drawing.Point(279, 330);
            this.linkLabel_DangKy.Name = "linkLabel_DangKy";
            this.linkLabel_DangKy.Size = new System.Drawing.Size(50, 15);
            this.linkLabel_DangKy.TabIndex = 4;
            this.linkLabel_DangKy.TabStop = true;
            this.linkLabel_DangKy.Text = "Đăng ký";
            this.linkLabel_DangKy.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_DangKy_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 231);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Email:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 278);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Mật khẩu:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.Image = global::client1.Properties.Resources.meo_dangnhap1;
            this.pictureBox1.Location = new System.Drawing.Point(85, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(244, 156);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Harlow Solid Italic", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(132, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 40);
            this.label3.TabIndex = 8;
            this.label3.Text = "Meow Mail";
            // 
            // DangNhap
            // 
            this.AcceptButton = this.button_dangnhap;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(417, 446);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.linkLabel_DangKy);
            this.Controls.Add(this.linkLabel_QuenPass);
            this.Controls.Add(this.textbox_pass);
            this.Controls.Add(this.textbox_TenTK);
            this.Controls.Add(this.button_dangnhap);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "DangNhap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DangNhap";
            this.TransparencyKey = System.Drawing.SystemColors.ActiveBorder;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button button_dangnhap;
        private TextBox textbox_TenTK;
        private TextBox textbox_pass;
        private LinkLabel linkLabel_QuenPass;
        private LinkLabel linkLabel_DangKy;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox1;
        private Label label3;
    }
}