﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace connect
{
    public partial class DangKy : Form
    {
        public DangKy()
        {
            InitializeComponent();
        }

        public bool checkAccount(string ac) //check acc
        {
            return Regex.IsMatch(ac, "^[a-zA-Z0-9,' ','á','à','ả','ã','ạ','â','ấ','ầ','ẩ','ẫ','ậ','é','è','ẻ','ẽ','ẹ','ê','ế','ề','ể','ễ','ệ','ó','ò','ỏ','õ','ọ','ô','ố','ồ','ổ','ỗ','ộ','í','ì','ỉ','ĩ','ị','ú','ù','ủ','ũ','ụ','ư','ứ','ừ','ử','ữ','ự','ă','ắ','ằ','ẳ','ẵ','ặ']{1,100}$");
        }
        public bool checkEmail(string em) // check email
        {
            return Regex.IsMatch(em, @"^[a-zA-Z0-9_.]{3,20}@meowmail.com(.vn|)$");
        }

        private void DangKy_Load(object sender, EventArgs e)
        {

        }
        Modify modify = new Modify();
        public static string email = "";
        private void button1_Click(object sender, EventArgs e)
        {
            string tenTK = textBox1.Text;
            string MK = textBox2.Text;
            string xnMK = textBox3.Text;
            email = textBox4.Text;

            if (!checkEmail(email))
            {
                MessageBox.Show("Vui lòng nhập email chính xác");
                return;
            }
            if (!checkAccount(tenTK))
            {
                MessageBox.Show("Vui lòng nhập tên dài 1-24 ký tự");
                return;
            }
            if (!checkAccount(MK))
            {
                MessageBox.Show("Vui lòng nhập mật khẩu 6-24 ký tự");
                return;
            }
            if (xnMK != MK)
            {
                MessageBox.Show("Vui lòng nhập đúng mật khẩu");
                return;
            }
            if (modify.Taikhoans("Select * from TaiKhoan where Email = '" + email + "'").Count != 0)
            {
                MessageBox.Show("Email này đã được đăng ký");
                return;
            }
            try
            {
                string query = "Insert into TaiKhoan values ('" + tenTK + "', '" + MK + "', '" + email + "')";
                modify.Command(query);
                if (MessageBox.Show("Đăng ký thành công, quay lại đăng nhập ?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Tên tài khoản đã được đăng ký");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
