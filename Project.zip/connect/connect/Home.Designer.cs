﻿namespace connect
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.receive_mail_button = new System.Windows.Forms.Button();
            this.send_mail_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.logout_button = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // receive_mail_button
            // 
            this.receive_mail_button.Location = new System.Drawing.Point(66, 259);
            this.receive_mail_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.receive_mail_button.Name = "receive_mail_button";
            this.receive_mail_button.Size = new System.Drawing.Size(218, 58);
            this.receive_mail_button.TabIndex = 0;
            this.receive_mail_button.Text = "Send";
            this.receive_mail_button.UseVisualStyleBackColor = true;
            this.receive_mail_button.Click += new System.EventHandler(this.receive_mail_button_Click);
            // 
            // send_mail_button
            // 
            this.send_mail_button.Location = new System.Drawing.Point(66, 333);
            this.send_mail_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.send_mail_button.Name = "send_mail_button";
            this.send_mail_button.Size = new System.Drawing.Size(218, 58);
            this.send_mail_button.TabIndex = 1;
            this.send_mail_button.Text = "View";
            this.send_mail_button.UseVisualStyleBackColor = true;
            this.send_mail_button.Click += new System.EventHandler(this.send_mail_button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::client1.Properties.Resources.meo_home1;
            this.pictureBox1.Location = new System.Drawing.Point(77, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 154);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Harlow Solid Italic", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(86, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 40);
            this.label3.TabIndex = 9;
            this.label3.Text = "Meow Mail";
            // 
            // logout_button
            // 
            this.logout_button.AutoSize = true;
            this.logout_button.Location = new System.Drawing.Point(259, 422);
            this.logout_button.Name = "logout_button";
            this.logout_button.Size = new System.Drawing.Size(48, 15);
            this.logout_button.TabIndex = 10;
            this.logout_button.TabStop = true;
            this.logout_button.Text = "Log out";
            this.logout_button.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.logout_button_LinkClicked);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 479);
            this.Controls.Add(this.logout_button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.send_mail_button);
            this.Controls.Add(this.receive_mail_button);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button receive_mail_button;
        private Button send_mail_button;
        private PictureBox pictureBox1;
        private Label label3;
        private LinkLabel logout_button;
    }
}