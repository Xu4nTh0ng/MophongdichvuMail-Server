﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Net.Mail;
using System.Net;


namespace connect
{
    public partial class Send : Form
    {
        public Send()
        {
            InitializeComponent();
        }

        private void send_button_Click(object sender, EventArgs e)
        {
            Guimail(sender_textbox.Text, recipient_textbox.Text, subject_textbox.Text, body_richtextbox.Text);

        }

        void Guimail(string from, string to, string subject, string message) {
            MailMessage mail = new MailMessage(from, to, subject, message);
            SmtpClient client = new SmtpClient("127.0.0.1");
            
            client.Send(mail);  
        }

        private void Send_Load(object sender, EventArgs e)
        {
            sender_textbox.Text = DangNhap.email;
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void subject_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void sender_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void recipient_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void body_richtextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void preview_richtextbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void recipient_name_Click(object sender, EventArgs e)
        {

        }
    }
}
