﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace connect
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void receive_mail_button_Click(object sender, EventArgs e)
        {
            var mail_sender = new Send();
            mail_sender.ShowDialog();
        }

        private void send_mail_button_Click(object sender, EventArgs e)
        {
            var mail_receiver = new View();
            mail_receiver.ShowDialog();
        }

        private void logout_button_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            var dangnhap_new = new DangNhap();
            dangnhap_new.Closed += (s, args) => this.Close();
            dangnhap_new.ShowDialog();
        }
    }
}
