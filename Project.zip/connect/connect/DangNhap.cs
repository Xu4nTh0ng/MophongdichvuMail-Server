﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace connect
{
    public partial class DangNhap : Form
    {
        public DangNhap()
        {
            InitializeComponent();
        }
        Modify modify = new Modify();
        static public string email;
        static public string MK;
        private void button_dangnhap_Click(object sender, EventArgs e)
        {
            email = textbox_TenTK.Text;
            MK = textbox_pass.Text;
            if (email.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập email !");
            }
            else if (MK.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mật khẩu !");
            }
            else
            {
                string query = "Select * from TaiKhoan where Email = '" + email + "' and MatKhau = '" + MK + "'";
                if (modify.Taikhoans(query).Count != 0)
                {
                    MessageBox.Show("Đăng nhập thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    Home home = new Home();
                    home.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Tên tài khoản hoặc mật khẩu không chính xác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void linkLabel_QuenPass_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            QuenPass QuenPass = new QuenPass();
            QuenPass.ShowDialog();
        }

        private void linkLabel_DangKy_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DangKy DK = new DangKy();
            DK.ShowDialog();
        }
    }
}
