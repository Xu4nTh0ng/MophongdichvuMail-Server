﻿namespace connect
{
    partial class Send
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.preview_richtextbox = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.subject_textbox = new System.Windows.Forms.TextBox();
            this.sender_textbox = new System.Windows.Forms.TextBox();
            this.recipient_textbox = new System.Windows.Forms.TextBox();
            this.send_button = new System.Windows.Forms.Button();
            this.body_richtextbox = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.recipient_name = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.preview_richtextbox);
            this.groupBox2.Location = new System.Drawing.Point(472, 35);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(446, 640);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Preview";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // preview_richtextbox
            // 
            this.preview_richtextbox.Location = new System.Drawing.Point(10, 28);
            this.preview_richtextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.preview_richtextbox.Name = "preview_richtextbox";
            this.preview_richtextbox.ReadOnly = true;
            this.preview_richtextbox.Size = new System.Drawing.Size(428, 591);
            this.preview_richtextbox.TabIndex = 8;
            this.preview_richtextbox.Text = "";
            this.preview_richtextbox.TextChanged += new System.EventHandler(this.preview_richtextbox_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.subject_textbox);
            this.groupBox1.Controls.Add(this.sender_textbox);
            this.groupBox1.Controls.Add(this.recipient_textbox);
            this.groupBox1.Controls.Add(this.send_button);
            this.groupBox1.Controls.Add(this.body_richtextbox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.recipient_name);
            this.groupBox1.Location = new System.Drawing.Point(14, 35);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(446, 640);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Send";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // subject_textbox
            // 
            this.subject_textbox.Location = new System.Drawing.Point(123, 211);
            this.subject_textbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.subject_textbox.Name = "subject_textbox";
            this.subject_textbox.Size = new System.Drawing.Size(298, 27);
            this.subject_textbox.TabIndex = 1;
            this.subject_textbox.TextChanged += new System.EventHandler(this.subject_textbox_TextChanged);
            // 
            // sender_textbox
            // 
            this.sender_textbox.Location = new System.Drawing.Point(123, 68);
            this.sender_textbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.sender_textbox.Name = "sender_textbox";
            this.sender_textbox.ReadOnly = true;
            this.sender_textbox.Size = new System.Drawing.Size(298, 27);
            this.sender_textbox.TabIndex = 12;
            this.sender_textbox.TextChanged += new System.EventHandler(this.sender_textbox_TextChanged);
            // 
            // recipient_textbox
            // 
            this.recipient_textbox.Location = new System.Drawing.Point(123, 148);
            this.recipient_textbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.recipient_textbox.Name = "recipient_textbox";
            this.recipient_textbox.Size = new System.Drawing.Size(298, 27);
            this.recipient_textbox.TabIndex = 0;
            this.recipient_textbox.TextChanged += new System.EventHandler(this.recipient_textbox_TextChanged);
            // 
            // send_button
            // 
            this.send_button.Location = new System.Drawing.Point(274, 552);
            this.send_button.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.send_button.Name = "send_button";
            this.send_button.Size = new System.Drawing.Size(147, 51);
            this.send_button.TabIndex = 8;
            this.send_button.Text = "Send";
            this.send_button.UseVisualStyleBackColor = true;
            this.send_button.Click += new System.EventHandler(this.send_button_Click);
            // 
            // body_richtextbox
            // 
            this.body_richtextbox.Location = new System.Drawing.Point(29, 338);
            this.body_richtextbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.body_richtextbox.Name = "body_richtextbox";
            this.body_richtextbox.Size = new System.Drawing.Size(393, 205);
            this.body_richtextbox.TabIndex = 3;
            this.body_richtextbox.Text = "";
            this.body_richtextbox.TextChanged += new System.EventHandler(this.body_richtextbox_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 315);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Body:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Sender:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Subject:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // recipient_name
            // 
            this.recipient_name.AutoSize = true;
            this.recipient_name.Location = new System.Drawing.Point(41, 152);
            this.recipient_name.Name = "recipient_name";
            this.recipient_name.Size = new System.Drawing.Size(74, 20);
            this.recipient_name.TabIndex = 2;
            this.recipient_name.Text = "Recipient:";
            this.recipient_name.Click += new System.EventHandler(this.recipient_name_Click);
            // 
            // Send
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 709);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Send";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Send";
            this.Load += new System.EventHandler(this.Send_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox2;
        private RichTextBox preview_richtextbox;
        private GroupBox groupBox1;
        private TextBox subject_textbox;
        private TextBox sender_textbox;
        private TextBox recipient_textbox;
        private Button send_button;
        private RichTextBox body_richtextbox;
        private Label label5;
        private Label label4;
        private Label label2;
        public Label recipient_name;
    }
}