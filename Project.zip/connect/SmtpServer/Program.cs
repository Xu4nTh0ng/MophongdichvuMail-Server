﻿using SmtpServer;
using SmtpServer.ComponentModel;





var options = new SmtpServerOptionsBuilder()
            .ServerName("localhost")
            .Port(25, 587)
            .Build();

var serviceProvider = new ServiceProvider();
    serviceProvider.Add(new SampleMessageStore());
    serviceProvider.Add(new SampleUserAuthenticator());


var smtpServer = new SmtpServer.SmtpServer(options, serviceProvider);
await smtpServer.StartAsync(CancellationToken.None);








